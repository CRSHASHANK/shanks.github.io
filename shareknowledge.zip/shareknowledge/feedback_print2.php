<html>
<head>
	<title>Display image</title>
	<link rel="stylesheet" href="feed.css">
</head>
<body>
	<center>
	<form action="" method="post" enctype="multipart/form-data">
		<br><center><h2>Feedback and uploaded images from<br> ShareKnowledge<h2></center><br>
	<table width="50%" border="1" cellpadding="5" cellspacing="0">
		<thead>
			<tr>
				<th>Username</th>
				<th>place</th>
				<th>place image</th>
				<th>comment about SK</th>
			</tr>
			</thead>
			<?php
			 	include 'connect.php';
			 	$query2="SELECT * FROM printb;";
				$check=mysqli_query($connection,$query2);
				if(mysqli_num_rows($check))
				{
        				while($row=mysqli_fetch_assoc($check))
       					 {
       					 
       					 	$path=$row['pic_place'];
       					 	?>
       					 	<tr>
       					 		
       					 		<td><?php echo $row['name'] ;?></td>
       					 		<td><?php echo $row['place'] ;?></td>
       					 		<td><?php echo "<img src='$path' style='width:120px; height:100px;' >";?></td>
       					 		<td><?php echo $row['comment'] ;?></td>
       					 	</tr>
       						<?php
       						}
       					}
       				?>
       			</table>
       		</form>
       	</center>
       	</body>
   </html> 
       					 	
