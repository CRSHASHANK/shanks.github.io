<!DOCTYPE html>
<html lang="en">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="feed_form.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#insert').click(function(){
                var image_name=$('#pic').val();
                if(image_name=='')
                {
                    alert("please select image");
                    return false;
                }
                else{
        
                    var extension=$('#pic').val().split('.').pop().toLowerCase();
                    if(jQuery.inArray(extension,['png','jpg','jpeg','webp'])==-1)
                    {
                        alert('Invalid Image File');
                        $('#pic').val('');
                        return false;
                    }
                }
            });
        });
    </script>
</head>
<body>
<h1>ShareKnowledge</h1><br><br>
    <i><div class="container">
        <h3 align="center">Feedback and Upload <br> famous places images in your area</h3>
        <form action="feed_database.php" method="post"  id="form" enctype="multipart/form-data">
            <label for="name">your name:</label><br><br>
            <input type="text" name="name" id="name" required><br><br>
             <label for="place">which type of   famous place  you want to upload </label><br><br>
            <select name="place" id="place" name="place">
                <option value="tourist" default>Tourist</option>
                <option value="Devotional">Devotional</option>
                <option value="others">Others</option>
            </select><br><br>
            <label for="p_name">Please mention place:</label><br><br>
            <input type="text" name="p_name" id="p_name" required><br><br>
            
            <label for="file">Upload image here</label><br><br>
            <input type="file" id="pic" name="picture"><br><br>
            <label for="msg">How is your experience wih our shareknowledge?</label><br><br>
            <input type="text"  id="msg" name="msg"required><br><br><br>
            <div class="btn">
                <button type="submit" name="insert" id="insert">submit</button>
                <button type="reset">reset</button>
            </div>
        </form>
    </div></i>

</body>
</html>