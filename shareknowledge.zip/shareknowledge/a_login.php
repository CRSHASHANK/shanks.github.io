<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>new tab</title>

</head>
<style>
    body{
        background-image:linear-gradient(powderblue,white,powderblue);
    	 }
    .container{
        height:100vh;
        display: grid;
        justify-content: center;
        align-items: center;
        
    }
    .inner{
        width:500px;
        height:200px;
        background-color:black;
        color:white;
        font-weight:400px;
        text-transform: capitalize;
        text-align: center;
        border-radius: 100px;
        padding: 10px;
        padding-top:30px ;
    }
    button{
        width:100px;
        height:40px;
       
        margin-right: 30px;
        border-radius:80px;
        background-color:skyblue;
        
        
    }
    .head{
     padding-bottom:20px;
     line-height:1.4;
     color:yellow;
     }
     	marquee{
     	color:black;
     	}
    
   </style>
<body>
	<marquee id="mar" ><i><h2>**Keep knowing about our India**ShareKnowledge**Jai Hind**</h2></i></marquee>
	
    <div class="container">
        <div class="inner">
           <h3 class="head">Your Are already login into shareknowledge</h3>
            <a href="p1.html"><button> Home</button></a>
            <a href="feed_form2.php"><button>feedback</button></a>
        </div>
    </div>
</body>
</html>
