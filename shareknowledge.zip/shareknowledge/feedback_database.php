<?php
$connection=mysqli_connect("localhost","root","","sharek");
include 'details.php'
if(isset($_POST['insert']))
{
    //$filename = explode(".", $_FILES['picture']['name']); //split by '.'
    //array_pop($filename); //remove the last segment
    //$filename = implode(".", $filename);

    //$file =addslashes(file_get_contents($_POST['picture']['tmp_name']));
   
    /*if($connection)
    {
   echo "connection established.'<br>' ";
   }*/
    $query="CREATE TABLE feedbackp(name  VARCHAR(15)  NOT NULL, place  VARCHAR(15) NOT NULL ,comment VARCHAR(15) NOT NULL,pic_place BLOB);";
    if(mysqli_query($connection,$query))
    {
        echo 'table created';
    }
  
    $query2="INSERT INTO feedbackp VALUES('$name','$p_name','$msg',$filename')";
    $data=mysqli_query($connection,$query2);
    if($data)
    {
        echo "data inserted";
      
    }
}
else{
    echo "there is a problem in uploading image";
}

?>
