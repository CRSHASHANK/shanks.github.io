<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>new tab</title>

</head>
<style>
    body{
        background-image: linear-gradient(powderblue,white);
    	 }
    .container{
        height:100vh;
        display: grid;
        justify-content: center;
        align-items: center;
        
    }
    .inner{
        width:500px;
        height:200px;
        background-color:black;
        color:white;
        font-weight:400px;
        text-transform: capitalize;
        text-align: center;
        border-radius: 100px;
        padding: 10px;
        padding-top:30px ;
    }
    button{
        width:80px;
        height:20px;
        border-radius:80px;
        background-color:skyblue;
        
        
    }
    .head{
     padding-bottom:10px;
     color:yellow;
     }
     h6{
        color:skyblue;
     }
     	marquee{
     	color:black;
     	}
    
   </style>
<body>
	<marquee id="mar" ><i><h2>**Keep knowing about our India**ShareKnowledge**Jai Hind**</h2></i></marquee>
	<img src="">
    <div class="container">
        <div class="inner">
           <h2 class="head">Thank you for your feedback</h2>
           <h6 class="head1">Your image is successfully uploaded,we will try to get the info about your mentioned area and place that in our shareknoweldge</h6>
            <a href="p1.html"><button> Home</button></a>
        </div>
    </div>
</body>
</html>
