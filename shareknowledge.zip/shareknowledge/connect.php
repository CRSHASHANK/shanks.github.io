<?php
$connection=mysqli_connect("localhost","root","","sharek");
//if($connection)
/*{
    echo "connection successfull";
}
else
{
    echo "error";
}*/
?>
