<?php
include 'connect.php';
if(isset($_POST['insert']))
{
    //$filename = explode(".", $_FILES['picture']['name']); //split by '.'
    //array_pop($filename); //remove the last segment
    //$filename = implode(".", $filename);

    //$file =addslashes(file_get_contents($_POST['picture']['tmp_name']));
    $name=mysqli_real_escape_string($connection,$_POST['name']);
    $p_name=mysqli_real_escape_string($connection,$_POST['p_name']);
    $msg=mysqli_real_escape_string($connection,$_POST['msg']);
    $filename=$_FILES["picture"]["name"];
     $tempname=$_FILES["picture"]["tmp_name"];
    $folder="uploads/".$filename;
    move_uploaded_file($tempname,$folder);
    /*if($connection)
    {
   echo "connection established.'<br>' ";
   }*/
   /* $query="CREATE TABLE  printb(name  VARCHAR(15)  NOT NULL, place  VARCHAR(15) NOT NULL ,comment VARCHAR(15) NOT NULL,pic_place BLOB);";
    if(mysqli_query($connection,$query))
    {asAS@#23
        echo 'table created';
    }*/
 
    $query2="INSERT INTO  printb VALUES ('$name','$p_name','$msg','$folder');";
    $data=mysqli_query($connection,$query2);

    if($data)
    {
        header("Location:feed_msg.php");
      
    }
    else
    {
        echo "sorry,try again";
    }
  
}
else{
    echo "there is a problem in uploading image";
}

?>
