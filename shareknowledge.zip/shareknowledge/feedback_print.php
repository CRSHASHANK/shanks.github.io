<html>
<head>
	<title>Display image</title>
	<link rel="stylesheet" href="feed.css">
</head>
<body>
	<center class="one">
	<form action="" method="post" enctype="multipart/form-data">
	
	<table width="50%" border="1" cellpadding="5" cellspacing="0">
		<thead>
			<tr>
				<th>Username</th>
				<th>place</th>
				<th>place image</th>
				<th>comment about SK</th>
			</tr>
			</thead>
			<?php
			 	include 'connect.php';
			 	$query2="SELECT * FROM feedback5;";
				$check=mysqli_query($connection,$query2);
				if(mysqli_num_rows($check))
				{
        				while($row=mysqli_fetch_assoc($check))
       					 {
       					 	?>
       					 	<tr>
       					 		
       					 		<td><?php echo $row['name'] ;?></td>
       					 		<td><?php echo $row['place'] ;?></td>
       					 		<td><?php echo '<img src="$row['pic_place']" ';?></td>
       					 		<td><?php echo $row['comment'] ;?></td>
       					 	</tr>
       						<?php
       						}
       					}
       				?>
       			</table>
       		</form>
       	</center>
       	</body>
   </html> 
       					 	
